<?php
define('DB_NAME', 'rangeros_wp');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

define('AUTH_KEY',         'rangeros-auth-key-unique');
define('SECURE_AUTH_KEY',  'rangeros-secure-auth-key-unique');
define('LOGGED_IN_KEY',    'rangeros-logged-in-key-unique');
define('NONCE_KEY',        'rangeros-nonce-key-unique');
define('AUTH_SALT',        'rangeros-auth-salt-unique');
define('SECURE_AUTH_SALT', 'rangeros-secure-auth-salt-unique');
define('LOGGED_IN_SALT',   'rangeros-logged-in-salt-unique');
define('NONCE_SALT',       'rangeros-nonce-salt-unique');

$table_prefix = 'wp_';

define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);

if ( ! defined( 'ABSPATH' ) ) {
    define( 'ABSPATH', __DIR__ . '/' );
}

require_once ABSPATH . 'wp-settings.php';
?>