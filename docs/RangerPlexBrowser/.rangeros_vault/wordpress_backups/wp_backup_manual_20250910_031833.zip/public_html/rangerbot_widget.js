/**
 * RangerBot Cool Widget for RangerOS
 * Super smooth, hover-to-expand, click-to-stay functionality
 * No more annoying show/hide - just hover for instant access!
 * 
 * Features:
 * - Hover to expand instantly
 * - Click to pin open/closed
 * - Smooth animations and transitions
 * - Smart positioning that doesn't cover content
 * - Cool visual effects
 */

(function() {
    'use strict';
    
    console.log('🚀 Loading RangerBot Cool Widget...');
    
    class CoolRangerBotWidget {
        constructor() {
            this.isPinned = localStorage.getItem('rangerbot_pinned') === 'true';
            this.isExpanded = this.isPinned;
            this.isHovering = false;
            this.sessionId = this.generateSessionId();
            this.messages = [];
            
            // Page context detection
            this.currentPage = window.location.pathname;
            this.pageType = this.detectPageType();
            this.pageHelp = this.getPageSpecificHelp();
            
            // Drag functionality
            this.isDragging = false;
            this.dragStartY = 0;
            this.widgetStartTop = 120;
            this.currentTop = parseInt(localStorage.getItem('rangerbot_position_top') || '120');
            
            this.init();
        }
        
        init() {
            this.setupGlobalKeyboardShortcuts();
            this.addCoolStyles();
            this.createCoolButton();
            this.createSlidingWidget();
            this.bindEvents();
            
            // Show welcome if first time
            if (!localStorage.getItem('rangerbot_cool_welcomed')) {
                setTimeout(() => this.showWelcome(), 1500);
            }
        }
        
        setupGlobalKeyboardShortcuts() {
            // Global keyboard shortcuts for RangerBot
            document.addEventListener('keydown', (e) => {
                // Ctrl+Cmd+W to toggle widget visibility
                if (e.ctrlKey && e.metaKey && e.key === 'w') {
                    e.preventDefault();
                    this.toggleVisibility();
                    console.log('⌨️ Widget toggled via Ctrl+Cmd+W');
                }
            });
            
            console.log('⌨️ Global shortcuts: Ctrl+Cmd+W (widget toggle)');
        }
        
        addCoolStyles() {
            const style = document.createElement('style');
            style.textContent = `
                :root {
                    --ranger-primary: #0a0e27;
                    --ranger-secondary: #1a1f3a;
                    --ranger-neon-blue: #00d4ff;
                    --ranger-neon-purple: #8a2be2;
                    --ranger-neon-green: #00ff88;
                }
                
                .rangerbot-cool-button {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    width: 60px;
                    height: 60px;
                    border-radius: 50%;
                    background: linear-gradient(135deg, var(--ranger-primary), var(--ranger-secondary));
                    border: 2px solid var(--ranger-neon-blue);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    cursor: pointer;
                    z-index: 10001;
                    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                    box-shadow: 0 4px 20px rgba(0, 212, 255, 0.3);
                    color: white;
                    font-size: 24px;
                    user-select: none;
                }
                
                .rangerbot-cool-button:hover {
                    transform: scale(1.1) rotate(10deg);
                    box-shadow: 0 8px 35px rgba(0, 212, 255, 0.6);
                    border-color: var(--ranger-neon-purple);
                    background: linear-gradient(135deg, var(--ranger-neon-blue), var(--ranger-neon-purple));
                }
                
                .rangerbot-cool-button.pinned {
                    background: linear-gradient(135deg, var(--ranger-neon-green), var(--ranger-neon-blue));
                    border-color: var(--ranger-neon-green);
                    animation: pulse-pinned 2s infinite;
                }
                
                @keyframes pulse-pinned {
                    0%, 100% { box-shadow: 0 4px 20px rgba(0, 255, 136, 0.4); }
                    50% { box-shadow: 0 6px 30px rgba(0, 255, 136, 0.8); }
                }
                
                .rangerbot-sliding-widget {
                    position: fixed;
                    top: 120px;
                    right: -420px;
                    width: 400px;
                    height: 550px;
                    background: var(--ranger-primary);
                    border: 2px solid var(--ranger-neon-blue);
                    border-radius: 20px 0 0 20px;
                    z-index: 10002;
                    transition: right 0.5s cubic-bezier(0.23, 1, 0.32, 1);
                    display: flex;
                    flex-direction: column;
                    box-shadow: -10px 10px 50px rgba(0, 212, 255, 0.3);
                    overflow: hidden;
                    cursor: move;
                }
                
                .rangerbot-sliding-widget.expanded {
                    right: 0;
                    box-shadow: -15px 15px 60px rgba(0, 212, 255, 0.5);
                }
                
                .rangerbot-sliding-widget.pinned {
                    border-color: var(--ranger-neon-green);
                    box-shadow: -10px 10px 40px rgba(0, 255, 136, 0.4);
                }
                
                .cool-widget-header {
                    background: linear-gradient(135deg, var(--ranger-neon-blue), var(--ranger-neon-purple));
                    color: white;
                    padding: 15px 20px;
                    font-weight: bold;
                    display: flex;
                    justify-content: between;
                    align-items: center;
                    border-bottom: 2px solid var(--ranger-neon-blue);
                }
                
                .cool-widget-title {
                    flex: 1;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                }
                
                .cool-pin-btn {
                    background: rgba(255,255,255,0.2);
                    border: none;
                    color: white;
                    padding: 6px 10px;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 0.9em;
                    transition: all 0.3s ease;
                }
                
                .cool-pin-btn:hover {
                    background: rgba(255,255,255,0.4);
                    transform: scale(1.05);
                }
                
                .cool-pin-btn.pinned {
                    background: var(--ranger-neon-green);
                    color: var(--ranger-primary);
                }
                
                .cool-widget-chat {
                    flex: 1;
                    padding: 15px;
                    background: var(--ranger-secondary);
                    overflow-y: auto;
                    color: white;
                    max-height: 300px;
                }
                
                .cool-widget-input-area {
                    padding: 15px;
                    background: var(--ranger-primary);
                    border-top: 2px solid var(--ranger-neon-blue);
                    display: flex;
                    gap: 10px;
                    align-items: flex-end;
                }
                
                .cool-widget-input {
                    flex: 1;
                    background: var(--ranger-secondary);
                    border: 1px solid var(--ranger-neon-blue);
                    color: white;
                    padding: 12px;
                    border-radius: 8px;
                    resize: none;
                    max-height: 80px;
                    font-family: inherit;
                }
                
                .cool-widget-input:focus {
                    outline: none;
                    border-color: var(--ranger-neon-purple);
                    box-shadow: 0 0 15px rgba(138, 43, 226, 0.4);
                }
                
                .cool-widget-send {
                    background: var(--ranger-neon-blue);
                    color: var(--ranger-primary);
                    border: none;
                    padding: 12px 16px;
                    border-radius: 8px;
                    cursor: pointer;
                    font-weight: bold;
                    transition: all 0.3s ease;
                }
                
                .cool-widget-send:hover {
                    background: var(--ranger-neon-purple);
                    color: white;
                    transform: translateY(-2px);
                }
                
                .cool-message {
                    margin: 10px 0;
                    padding: 10px 12px;
                    border-radius: 12px;
                    max-width: 90%;
                    line-height: 1.4;
                    animation: slideIn 0.3s ease;
                }
                
                .cool-message.user {
                    background: var(--ranger-neon-blue);
                    color: var(--ranger-primary);
                    margin-left: auto;
                    border-bottom-right-radius: 4px;
                }
                
                .cool-message.ai {
                    background: var(--ranger-secondary);
                    color: white;
                    border-left: 3px solid var(--ranger-neon-green);
                    border-bottom-left-radius: 4px;
                }
                
                .cool-message.system {
                    background: rgba(138, 43, 226, 0.2);
                    color: var(--ranger-neon-purple);
                    text-align: center;
                    font-style: italic;
                    margin: 8px auto;
                    font-size: 0.9em;
                    border: 1px solid var(--ranger-neon-purple);
                }
                
                @keyframes slideIn {
                    from { opacity: 0; transform: translateX(20px); }
                    to { opacity: 1; transform: translateX(0); }
                }
                
                .cool-hover-hint {
                    position: fixed;
                    top: 85px;
                    right: 85px;
                    background: rgba(0, 212, 255, 0.1);
                    border: 1px solid var(--ranger-neon-blue);
                    color: var(--ranger-neon-blue);
                    padding: 8px 12px;
                    border-radius: 20px;
                    font-size: 0.8em;
                    z-index: 9998;
                    opacity: 0;
                    transition: all 0.3s ease;
                    pointer-events: none;
                    backdrop-filter: blur(5px);
                }
                
                .cool-hover-hint.show {
                    opacity: 1;
                    transform: translateY(-5px);
                }
                
                .quick-action-btn {
                    background: rgba(0, 255, 136, 0.1);
                    border: 1px solid var(--ranger-neon-green);
                    color: var(--ranger-neon-green);
                    padding: 4px 8px;
                    border-radius: 12px;
                    cursor: pointer;
                    font-size: 0.75em;
                    transition: all 0.3s ease;
                    white-space: nowrap;
                }
                
                .quick-action-btn:hover {
                    background: var(--ranger-neon-green);
                    color: var(--ranger-primary);
                    transform: translateY(-1px);
                }
                
                /* Mobile responsive */
                @media (max-width: 500px) {
                    .rangerbot-sliding-widget {
                        width: calc(100vw - 20px);
                        right: -100vw;
                        top: 80px;
                        height: calc(100vh - 100px);
                        border-radius: 20px 0 0 0;
                    }
                    
                    .rangerbot-sliding-widget.expanded {
                        right: 10px;
                    }
                    
                    .rangerbot-cool-button {
                        width: 55px;
                        height: 55px;
                        top: 15px;
                        right: 15px;
                        font-size: 20px;
                    }
                }
            `;
            document.head.appendChild(style);
        }
        
        createCoolButton() {
            this.button = document.createElement('div');
            this.button.className = 'rangerbot-cool-button';
            this.button.innerHTML = '🤖';
            this.button.title = 'RangerBot AI Assistant - Hover to peek, Click to pin!';
            
            // Add hover hint
            this.hoverHint = document.createElement('div');
            this.hoverHint.className = 'cool-hover-hint';
            this.hoverHint.textContent = this.isPinned ? 'Click to unpin' : 'Hover to peek, Click to pin';
            
            document.body.appendChild(this.button);
            document.body.appendChild(this.hoverHint);
            
            if (this.isPinned) {
                this.button.classList.add('pinned');
            }
            
            console.log('✅ Cool RangerBot button created');
        }
        
        createSlidingWidget() {
            this.widget = document.createElement('div');
            this.widget.className = 'rangerbot-sliding-widget';
            
            // Set saved position
            this.widget.style.top = this.currentTop + 'px';
            
            if (this.isPinned) {
                this.widget.classList.add('expanded', 'pinned');
            }
            
            this.widget.innerHTML = `
                <div class="cool-widget-header" id="cool-drag-handle">
                    <div class="cool-widget-title">
                        🤖 RangerBot Cool
                        <span style="font-size: 0.8em; opacity: 0.9;">Drag to Move | Click to Pin</span>
                    </div>
                    <div style="display: flex; gap: 8px;">
                        <button class="cool-pin-btn" id="cool-voice" title="Voice Commands">🎤</button>
                        <button class="cool-pin-btn" id="cool-email" title="Email Functions">📧</button>
                        <button class="cool-pin-btn" id="cool-settings" title="Settings">⚙️</button>
                        <button class="cool-pin-btn" id="cool-system" title="System Info">🖥️</button>
                        <button class="cool-pin-btn ${this.isPinned ? 'pinned' : ''}" id="cool-pin-toggle">
                            ${this.isPinned ? '📌' : '📌'}
                        </button>
                    </div>
                </div>
                
                <div class="cool-widget-chat" id="cool-chat">
                    <div class="cool-message system">
                        🚀 RangerBot on ${this.pageHelp.title.replace(' Help', '')} Page!<br>
                        <strong>Drag header</strong> to move, <strong>click ${this.pageHelp.icon} ${this.pageHelp.title}</strong> for page-specific help<br>
                        <em>Contextual AI assistance for RangerOS!</em>
                    </div>
                </div>
                
                <div style="padding: 10px 15px; background: rgba(0,212,255,0.1); border-top: 1px solid #00d4ff;">
                    <div style="display: flex; gap: 8px; flex-wrap: wrap; justify-content: center;" id="quick-actions-container">
                        ${this.generateQuickActions()}
                    </div>
                </div>
                
                <div class="cool-widget-input-area">
                    <textarea class="cool-widget-input" id="cool-input" 
                             placeholder="Ask RangerBot anything (spacebar works!)..." rows="1"></textarea>
                    <button class="cool-widget-send" id="cool-send">Send</button>
                </div>
            `;
            
            document.body.appendChild(this.widget);
            console.log('✅ Cool sliding widget created');
        }
        
        bindEvents() {
            // Button hover events
            this.button.addEventListener('mouseenter', () => {
                if (!this.isPinned) {
                    this.expandWidget();
                    this.showHint('Click to pin open!');
                }
            });
            
            this.button.addEventListener('mouseleave', () => {
                if (!this.isPinned) {
                    // Delay collapse to allow moving to widget
                    setTimeout(() => {
                        if (!this.isHovering && !this.isPinned) {
                            this.collapseWidget();
                        }
                    }, 500);
                }
                this.hideHint();
            });
            
            // Button click to pin/unpin
            this.button.addEventListener('click', () => {
                this.togglePin();
            });
            
            // Widget hover events
            this.widget.addEventListener('mouseenter', () => {
                this.isHovering = true;
            });
            
            this.widget.addEventListener('mouseleave', () => {
                this.isHovering = false;
                if (!this.isPinned) {
                    setTimeout(() => {
                        if (!this.isHovering && !this.isPinned) {
                            this.collapseWidget();
                        }
                    }, 300);
                }
            });
            
            // Pin button
            document.getElementById('cool-pin-toggle').addEventListener('click', () => {
                this.togglePin();
            });
            
            // Additional control buttons
            document.getElementById('cool-voice')?.addEventListener('click', () => {
                this.activateVoice();
            });
            
            document.getElementById('cool-email')?.addEventListener('click', () => {
                this.showEmailFeatures();
            });
            
            document.getElementById('cool-settings')?.addEventListener('click', () => {
                this.openSettings();
            });
            
            document.getElementById('cool-system')?.addEventListener('click', () => {
                this.showSystemInfo();
            });
            
            // Drag functionality
            this.setupDragFunctionality();
            
            // Send button and input
            document.getElementById('cool-send').addEventListener('click', () => {
                this.sendMessage();
            });
            
            const input = document.getElementById('cool-input');
            
            // Prevent VLC controls from interfering with chat input
            input.addEventListener('keydown', (e) => {
                e.stopPropagation(); // Stop event from bubbling up to VLC handlers
            });
            
            input.addEventListener('keyup', (e) => {
                e.stopPropagation(); // Stop event from bubbling up to VLC handlers
            });
            
            input.addEventListener('keypress', (e) => {
                e.stopPropagation(); // Stop event from bubbling up to VLC handlers
                
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
            
            // Auto-resize textarea
            input.addEventListener('input', (e) => {
                e.stopPropagation();
                input.style.height = 'auto';
                input.style.height = Math.min(input.scrollHeight, 80) + 'px';
            });
            
            // Extra protection for focus events
            input.addEventListener('focus', () => {
                console.log('🎯 RangerBot input focused - VLC controls disabled');
                // Add visual indicator that input is active
                input.style.borderColor = 'var(--ranger-neon-green)';
                input.style.boxShadow = '0 0 15px rgba(0, 255, 136, 0.4)';
            });
            
            input.addEventListener('blur', () => {
                console.log('🎯 RangerBot input blurred - VLC controls re-enabled');
                // Remove visual indicator
                input.style.borderColor = 'var(--ranger-neon-blue)';
                input.style.boxShadow = 'none';
            });
        }
        
        setupDragFunctionality() {
            const dragHandle = document.getElementById('cool-drag-handle');
            
            dragHandle.addEventListener('mousedown', (e) => {
                if (e.target.tagName === 'BUTTON') return; // Don't drag when clicking buttons
                
                this.isDragging = true;
                this.dragStartY = e.clientY;
                this.widgetStartTop = this.currentTop;
                
                // Visual feedback
                this.widget.style.transition = 'none';
                dragHandle.style.cursor = 'grabbing';
                dragHandle.style.background = 'linear-gradient(135deg, var(--ranger-neon-purple), var(--ranger-neon-blue))';
                
                console.log('🖱️ Started dragging widget');
                e.preventDefault();
            });
            
            document.addEventListener('mousemove', (e) => {
                if (!this.isDragging) return;
                
                const deltaY = e.clientY - this.dragStartY;
                const newTop = Math.max(10, Math.min(window.innerHeight - 100, this.widgetStartTop + deltaY));
                
                this.widget.style.top = newTop + 'px';
                this.currentTop = newTop;
            });
            
            document.addEventListener('mouseup', () => {
                if (this.isDragging) {
                    this.isDragging = false;
                    
                    // Save position
                    localStorage.setItem('rangerbot_position_top', this.currentTop.toString());
                    
                    // Restore styling
                    this.widget.style.transition = 'right 0.5s cubic-bezier(0.23, 1, 0.32, 1)';
                    const dragHandle = document.getElementById('cool-drag-handle');
                    dragHandle.style.cursor = 'move';
                    dragHandle.style.background = 'linear-gradient(135deg, var(--ranger-neon-blue), var(--ranger-neon-purple))';
                    
                    console.log('🖱️ Widget positioned at:', this.currentTop + 'px');
                    this.addMessage('system', `📍 Widget moved to position ${this.currentTop}px`);
                }
            });
        }
        
        openSettings() {
            const settingsUrl = '/03-web-interfaces/rangerbot_settings.html';
            window.open(settingsUrl, '_blank', 'width=900,height=700');
            this.addMessage('system', '⚙️ Settings panel opened!');
        }
        
        sendQuickMessage(message) {
            const input = document.getElementById('cool-input');
            if (input) {
                input.value = message;
                this.sendMessage();
            }
        }
        
        expandWidget() {
            this.widget.classList.add('expanded');
            this.isExpanded = true;
            console.log('🚀 Widget expanded');
        }
        
        collapseWidget() {
            if (!this.isPinned) {
                this.widget.classList.remove('expanded');
                this.isExpanded = false;
                console.log('📦 Widget collapsed');
            }
        }
        
        togglePin() {
            this.isPinned = !this.isPinned;
            
            const pinBtn = document.getElementById('cool-pin-toggle');
            
            if (this.isPinned) {
                this.button.classList.add('pinned');
                this.widget.classList.add('pinned');
                pinBtn.textContent = '📌 Pinned';
                pinBtn.classList.add('pinned');
                this.expandWidget();
                this.showHint('Pinned open! Click to unpin', 2000);
                console.log('📌 Widget pinned open');
            } else {
                this.button.classList.remove('pinned');
                this.widget.classList.remove('pinned');
                pinBtn.textContent = '📌 Pin Open';
                pinBtn.classList.remove('pinned');
                this.showHint('Unpinned! Hover to peek', 2000);
                console.log('📌 Widget unpinned');
            }
            
            localStorage.setItem('rangerbot_pinned', this.isPinned.toString());
            this.updateHintText();
        }
        
        showHint(text, duration = 1000) {
            this.hoverHint.textContent = text;
            this.hoverHint.classList.add('show');
            
            setTimeout(() => {
                this.hoverHint.classList.remove('show');
            }, duration);
        }
        
        hideHint() {
            this.hoverHint.classList.remove('show');
        }
        
        updateHintText() {
            this.hoverHint.textContent = this.isPinned ? 'Click to unpin' : 'Hover to peek, Click to pin';
            this.button.title = `RangerBot AI Assistant - ${this.isPinned ? 'Click to unpin' : 'Hover to peek, Click to pin!'}`;
        }
        
        async sendMessage() {
            const input = document.getElementById('cool-input');
            const message = input.value.trim();
            
            if (!message) return;
            
            console.log('🤖 Sending cool message:', message);
            
            // Add user message
            this.addMessage('user', message);
            input.value = '';
            input.style.height = 'auto';
            
            // Show typing indicator
            this.addMessage('ai', '🤖 RangerBot is thinking...');
            
            try {
                const response = await fetch('http://localhost:8003/api/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        message: message,
                        sessionId: this.sessionId,
                        context: { page: window.location.pathname, cool_widget: true }
                    })
                });
                
                // Remove typing indicator
                this.removeLastMessage();
                
                if (response.ok) {
                    const data = await response.json();
                    this.addMessage('ai', data.response || 'Response received');
                } else {
                    this.addMessage('ai', 'AI service temporarily unavailable. Please ensure RangerBot API is running on port 8003.');
                }
                
            } catch (error) {
                console.error('Cool widget error:', error);
                this.removeLastMessage();
                this.addMessage('ai', 'Connection error. Make sure RangerBot Ollama API is running (port 8003).');
            }
        }
        
        addMessage(type, content) {
            const chat = document.getElementById('cool-chat');
            if (!chat) return;
            
            const messageDiv = document.createElement('div');
            messageDiv.className = `cool-message ${type}`;
            messageDiv.innerHTML = this.formatMessage(content);
            
            chat.appendChild(messageDiv);
            chat.scrollTop = chat.scrollHeight;
            
            this.messages.push({ type, content, timestamp: Date.now() });
        }
        
        removeLastMessage() {
            const chat = document.getElementById('cool-chat');
            if (chat && chat.lastElementChild && chat.lastElementChild.classList.contains('cool-message')) {
                chat.removeChild(chat.lastElementChild);
            }
        }
        
        formatMessage(content) {
            return content
                .replace(/`([^`]+)`/g, '<code style="background: rgba(0,212,255,0.2); padding: 2px 5px; border-radius: 3px;">$1</code>')
                .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
                .replace(/\*([^*]+)\*/g, '<em>$1</em>')
                .replace(/\n/g, '<br>');
        }
        
        activateVoice() {
            if ('speechRecognition' in window || 'webkitSpeechRecognition' in window) {
                this.addMessage('system', '🎤 Voice recognition activated! Speak your question...');
                // Voice implementation would go here
            } else {
                this.addMessage('system', '🎤 Voice recognition not supported in this browser');
            }
        }
        
        showEmailFeatures() {
            this.addMessage('system', '📧 Email features available! You can ask me to compose emails, send reports, or help with email tasks.');
        }
        
        showSystemInfo() {
            // Enhanced system info like VLC version
            const systemInfo = this.getDetailedSystemInfo();
            const currentTime = new Date();
            const timeString = currentTime.toLocaleTimeString();
            const dateString = currentTime.toLocaleDateString();
            
            let info = `🖥️ **RangerOS System Information:**\n\n`;
            info += `**Current Time:** ${timeString} (${dateString})\n`;
            info += `**Page:** ${window.location.pathname}\n`;
            info += `**Browser:** ${systemInfo.browser}\n`;
            info += `**Screen Resolution:** ${systemInfo.screen}\n`;
            info += `**Available Memory:** ${systemInfo.memory}\n`;
            info += `**Platform:** ${systemInfo.platform}\n`;
            info += `**Language:** ${systemInfo.language}\n`;
            info += `**Online Status:** ${systemInfo.online ? 'Connected' : 'Offline'}\n\n`;
            info += `**RangerOS Services:**\n`;
            info += `• RangerBot AI: Active\n`;
            info += `• VLC Database: Available\n`;
            info += `• Media Server: Running\n\n`;
            info += `*I can help you with system tasks, file management, and RangerOS features!*`;
            
            this.addMessage('ai', info);
        }
        
        getDetailedSystemInfo() {
            return {
                browser: this.getBrowserName(),
                screen: `${screen.width}×${screen.height}`,
                memory: navigator.deviceMemory ? `${navigator.deviceMemory}GB` : 'Unknown',
                language: navigator.language,
                online: navigator.onLine,
                platform: navigator.platform,
                userAgent: navigator.userAgent.split(' ')[0] || 'Unknown'
            };
        }
        
        getBrowserName() {
            const userAgent = navigator.userAgent;
            if (userAgent.includes('Chrome')) return 'Chrome';
            if (userAgent.includes('Firefox')) return 'Firefox';
            if (userAgent.includes('Safari')) return 'Safari';
            if (userAgent.includes('Edge')) return 'Edge';
            return 'Unknown Browser';
        }
        
        detectPageType() {
            const path = this.currentPage.toLowerCase();
            
            if (path.includes('vlc')) return 'vlc';
            if (path.includes('gaming')) return 'gaming';
            if (path.includes('ai_') || path.includes('ollama')) return 'ai';
            if (path.includes('container')) return 'container';
            if (path.includes('memory') || path.includes('performance')) return 'monitoring';
            if (path.includes('security')) return 'security';
            if (path.includes('bookmark')) return 'bookmarks';
            if (path.includes('tron_matrix')) return 'matrix';
            if (path.includes('sticky') || path.includes('notes')) return 'notes';
            if (path.includes('marketplace')) return 'marketplace';
            if (path.includes('landing') || path.includes('rangeros')) return 'rangeros';
            if (path.includes('terminal')) return 'terminal';
            if (path.includes('obs') || path.includes('streaming')) return 'streaming';
            
            return 'general';
        }
        
        getPageSpecificHelp() {
            const pageHelps = {
                vlc: {
                    title: 'VLC Help',
                    icon: '🎵',
                    message: 'Help me with VLC media player features'
                },
                gaming: {
                    title: 'Gaming Help', 
                    icon: '🎮',
                    message: 'Help me with gaming features and setup'
                },
                ai: {
                    title: 'AI Help',
                    icon: '🧠', 
                    message: 'Help me with AI models and configuration'
                },
                container: {
                    title: 'Container Help',
                    icon: '📦',
                    message: 'Help me with Docker containers and management'
                },
                monitoring: {
                    title: 'Monitor Help',
                    icon: '📊',
                    message: 'Help me with system monitoring and performance'
                },
                security: {
                    title: 'Security Help',
                    icon: '🔒',
                    message: 'Help me with security features and settings'
                },
                bookmarks: {
                    title: 'Bookmark Help',
                    icon: '🔖',
                    message: 'Help me manage bookmarks and navigation'
                },
                matrix: {
                    title: 'Matrix Help',
                    icon: '🌌',
                    message: 'Help me with Tron Matrix features and controls'
                },
                notes: {
                    title: 'Notes Help',
                    icon: '📝',
                    message: 'Help me with sticky notes and course management'
                },
                marketplace: {
                    title: 'Store Help',
                    icon: '🛍️',
                    message: 'Help me with marketplace and app installations'
                },
                rangeros: {
                    title: 'RangerOS Help',
                    icon: '🚀',
                    message: 'Help me with RangerOS features and navigation'
                },
                terminal: {
                    title: 'Terminal Help',
                    icon: '💻',
                    message: 'Help me with terminal commands and container management'
                },
                streaming: {
                    title: 'Streaming Help',
                    icon: '📺',
                    message: 'Help me with OBS and streaming setup'
                },
                general: {
                    title: 'Page Help',
                    icon: '❓',
                    message: 'Help me with this page and its features'
                }
            };
            
            return pageHelps[this.pageType] || pageHelps.general;
        }
        
        generateQuickActions() {
            const help = this.pageHelp;
            return `
                <button class="quick-action-btn" onclick="coolRangerBot.sendQuickMessage('${help.message}')">${help.icon} ${help.title}</button>
                <button class="quick-action-btn" onclick="coolRangerBot.sendQuickMessage('Show system status')">📊 System</button>
                <button class="quick-action-btn" onclick="coolRangerBot.sendQuickMessage('What time is it?')">🕐 Time</button>
                <button class="quick-action-btn" onclick="coolRangerBot.sendQuickMessage('List available commands for this page')">❓ Commands</button>
            `;
        }
        
        // Enhanced message handling with better time responses
        async sendMessage() {
            const input = document.getElementById('cool-input');
            const message = input.value.trim();
            
            if (!message) return;
            
            console.log('🤖 Sending enhanced message:', message);
            
            // Add user message
            this.addMessage('user', message);
            input.value = '';
            input.style.height = 'auto';
            
            // Handle special commands locally first
            if (this.handleSpecialCommands(message)) {
                return;
            }
            
            // Show typing indicator
            this.addMessage('ai', '🤖 RangerBot is thinking...');
            
            try {
                const response = await fetch('http://localhost:8003/api/chat', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        message: message,
                        sessionId: this.sessionId,
                        context: {
                            page: window.location.pathname,
                            timestamp: new Date().toISOString(),
                            rangerOS: true,
                            cool_widget: true,
                            system_info: this.getDetailedSystemInfo()
                        }
                    })
                });
                
                // Remove typing indicator
                this.removeLastMessage();
                
                if (response.ok) {
                    const data = await response.json();
                    this.addMessage('ai', data.response || 'Response received');
                } else {
                    this.addMessage('ai', 'AI service temporarily unavailable. Please ensure RangerBot API is running on port 8003.');
                }
                
            } catch (error) {
                console.error('Enhanced widget error:', error);
                this.removeLastMessage();
                this.addMessage('ai', 'Connection error. Make sure RangerBot Ollama API is running (port 8003).');
            }
        }
        
        handleSpecialCommands(message) {
            const msg = message.toLowerCase();
            
            // Time commands
            if (msg.includes('time') || msg === 'time') {
                const now = new Date();
                const timeString = now.toLocaleTimeString();
                const response = `I'm happy to help! According to your RangerOS system, the current time is ${timeString}. If you need to set a reminder or schedule an event, I can assist you with that too!`;
                this.addMessage('ai', response);
                return true;
            }
            
            // System commands  
            if (msg.includes('system status') || msg.includes('system info')) {
                this.showSystemInfo();
                return true;
            }
            
            return false; // Let AI handle other messages
        }
        
        showWelcome() {
            this.expandWidget();
            this.showHint('Welcome to RangerBot Cool Widget!', 3000);
            localStorage.setItem('rangerbot_cool_welcomed', 'true');
        }
        
        generateSessionId() {
            return 'cool_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        }
    }
    
    // Initialize the cool widget
    let coolRangerBot;
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            coolRangerBot = new CoolRangerBotWidget();
            window.coolRangerBot = coolRangerBot;
            console.log('🚀 RangerBot Cool Widget initialized');
        });
    } else {
        coolRangerBot = new CoolRangerBotWidget();
        window.coolRangerBot = coolRangerBot;
        console.log('🚀 RangerBot Cool Widget initialized');
    }
    
    // Global API
    window.RangerBotCool = {
        sendMessage: function(message) {
            if (coolRangerBot) {
                const input = document.getElementById('cool-input');
                if (input) {
                    input.value = message;
                    coolRangerBot.sendMessage();
                }
            }
        },
        
        pin: function() {
            if (coolRangerBot && !coolRangerBot.isPinned) {
                coolRangerBot.togglePin();
            }
        },
        
        unpin: function() {
            if (coolRangerBot && coolRangerBot.isPinned) {
                coolRangerBot.togglePin();
            }
        },
        
        toggle: function() {
            if (coolRangerBot) {
                coolRangerBot.togglePin();
            }
        }
    };
    
    console.log('✨ RangerBot Cool Widget ready - Hover to peek, Click to pin!');
    
})();